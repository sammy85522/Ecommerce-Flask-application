from flask import Flask,render_template,request,redirect,url_for,session, flash
from flask_sqlalchemy import SQLAlchemy
#from flask_jwt_extended import JWTManager, create_access_token, get_jwt_identity, jwt_required
from flask_login import current_user, login_required, LoginManager, login_user, UserMixin, AnonymousUserMixin
from flask import request, flash
import bcrypt,random
from flask_mail import *  


app = Flask(__name__)

"""app.secret_key='g3uch3iuhc3ihc3899'
login_manager = LoginManager()
login_manager.init_app(app) 

@login_manager.user_loader
def load_user(user_id):
    if user_id is not None:
        return User.query.get(int(user_id))
    return AnonymousUserMixin()



"""


app.config['SECRET_KEY']='ajhfuqhoqfheq56'
app.config['JWT_SECRET_KEY']='super-secret'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///maindb.db'   #configuring the database uri 
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False  



db=SQLAlchemy(app)

login_manager = LoginManager()  #used to manage user sessions, protecting the routes that require authentication
login_manager.init_app(app) 


#this is used to retrieve the user object from a user ID stored in the session
@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))



#jwt=JWTManager(app)
"""@login_manager.user_loader
def load_user(user_id):
    return User.get(user_id)
"""
class User(db.Model,UserMixin):
    __tablename__ = "students"
    id = db.Column(db.Integer,primary_key=True)
    username = db.Column(db.String())
    password= db.Column(db.String())
 
 
    def __init__(self, username, password):
        self.username = username
        self.password = password

    def get_id(self):
        return self.id

 

class Product(db.Model):
    id = db.Column(db.Integer,primary_key=True)
    name = db.Column(db.String(),nullable=False)
    price= db.Column(db.Float, nullable=False)
    description=db.Column(db.String(),nullable=False)
    image_url=db.Column(db.String(),nullable=False)



class Cart(db.Model):
    id = db.Column(db.Integer,primary_key=True)
    user_id= db.Column(db.Integer,db.ForeignKey('students.id'))
    product_name= db.Column(db.String(),nullable=False)
    price= db.Column(db.Float, nullable=False)
    description=db.Column(db.String(),nullable=False)
    image_url=db.Column(db.String(),nullable=False)
    quantity= db.Column(db.Integer)


@app.route('/add_to_cart', methods=['POST','GET'])
@login_required
def add_to_cart():
    if request.method == 'POST':
        product_name = request.form.get('product_name')
        product_price = request.form.get('product_price')
        product_description = request.form.get('product_description')
        product_image_url = request.form.get('product_image_url')
        quantity=request.form.get('quantity')
        #user_id=current_user.id
       # Assuming you have a user and orders model, you can add the product to the user's orders.
        cart = Cart(
           user_id=current_user.id,
           product_name=product_name,
           price=product_price,
           description=product_description,
           image_url=product_image_url,
           quantity=quantity
       )
        db.session.add(cart)
        db.session.commit()
        mycartproducts=Cart.query.all()
        user_id=current_user.id
        #user_cart=Cart.query.filter(user_id=current_user.id).all()
        #mycartproducts=Cart.query.all()
        return render_template('mycart.html',mycartproducts=mycartproducts, user_id=user_id)
    mycartproducts=Cart.query.all()
    user_id=current_user.id
    return render_template('mycart.html',mycartproducts=mycartproducts, user_id=user_id)




@app.route('/remove_from_cart', methods=['POST','GET'])
@login_required
def remove_from_cart():
    if request.method == 'POST':
        #product_name = request.form.get('product_name')
       # Assuming you have a user and orders model, you can add the product to the user's orders.
        user_id=current_user.id
        rmcart = Cart.query.filter_by(user_id=user_id).first()
        db.session.delete(rmcart)
        db.session.commit()
        mycartproducts=Cart.query.all()
        return render_template('mycart.html',mycartproducts=mycartproducts,user_id=user_id)
    products=Product.query.all()
    return render_template('products.html',products=products)

@app.route('/')
def home():
    db.create_all()
    return render_template('index.html')

@app.route('/register',methods = ['GET','POST'])
def register():
    if request.method == 'POST':
        username = request.form['uname']
        password = request.form['psw']

        hashed_password=bcrypt.hashpw(password.encode('utf-8'),bcrypt.gensalt())

        new_user=User(username=username,password=hashed_password)
        db.session.add(new_user)
        db.session.commit()
        return redirect(url_for('home'))
    return render_template('registration.html')
    

@app.route('/login', methods=['POST','GET'])
def login():
    if request.method=="POST":
        username=request.form['uname']
        passowrd=request.form['psw']

        user=User.query.filter_by(username=username).first()

        if user and bcrypt.checkpw(passowrd.encode('utf-8'),user.password):
            login_user(user)
            session['logged_in']=True
            products=Product.query.all()
            return render_template('products.html',products=products)
            #return access_token
        else:
            return {"message":"invalid credentials shivanshu"}
        
    return render_template('login.html')


@app.route('/logout')
def logout():
    session.pop('logged_in',None)
    return redirect(url_for('home'))

"""@app.route('/get_token', methods=['GET'])
def get_token():
    return btoken
"""     


"""@app.route('/protected', methods=['GET'])
@jwt_required()
def protected_data():
    protected_url="http://localhost:5000/protected"
    current_user=get_jwt_identity()
    headers={
        'Authorization' : f'Bearer {btoken}'
    }
    response=requests.get(protected_url,headers=headers)
    if response.status_code==200:
        return {"message : access given to "+current_user}
    else:
        return {"message"  :  "access not provided"}
    
"""

"""@app.route('/protected', methods=['GET'])
@jwt_required()
def protected_data():
    current_user=get_jwt_identity()
    return {"message ": "access is given to "+current_user}
"""
app.run(host='localhost', port=5000)
